/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package employeeSalary;

import java.util.Scanner;

/**
 *
 * @author S555504 Narayana Potla
 */
public class EmployeeSalaryDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner scanobj=new Scanner(System.in);
        System.out.println("****Testing the EmployeeSalary class:****");
        System.out.println("Enter the insurance percentage of the Employee in percentage: ");
        double insurancePercentage=scanobj.nextDouble();
        System.out.println("Enter the tax percentage of the Employee in percentage: ");
        double taxPercentage=scanobj.nextDouble();
        System.out.println("Enter the pf percentage of the Employee in percentage: ");
        double pfPercentage=scanobj.nextDouble();
        System.out.println("Enter the bonus of the Employee: ");
        double bonus=scanobj.nextDouble();
        EmployeeSalary employee1=new EmployeeSalary(insurancePercentage,taxPercentage,pfPercentage);
        System.out.println("*****The details of employee1 object are as follows:*****\n");
        System.out.println(employee1.toString());
        System.out.println("The weekly salary of the Employee is: $"+employee1.calcWeeklySalary());
        System.out.println("The Annual salary of the Employee is: $"+employee1.calcAnnualSalary());
        System.out.println("The yearly insurance of the Employee is: $"+employee1.calcYearlyInsurance());
        System.out.println("The yearly pf of the Employee is: $"+employee1.calcYearlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $"+employee1.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $"+employee1.calcAnnualNetPay(bonus));
        
        EmployeeSalary employee2=new EmployeeSalary();
        System.out.println("*****The details of employee2 object are as follows:*****\n");
        System.out.println(employee2.toString());
        System.out.println("The weekly salary of the Employee is: "+employee2.calcWeeklySalary());
        System.out.println("The Annual salary of the Employee is: $"+employee2.calcAnnualSalary());
        System.out.println("The yearly insurance of the Employee is: "+employee2.calcYearlyInsurance());
        System.out.println("The yearly pf of the Employee is: "+employee2.calcYearlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: "+employee2.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: "+employee2.calcAnnualNetPay(bonus));
        employee2.setInsurancePercentage(10.5);
        employee2.setTaxPercentage(15.45);
        employee2.setPfPercentage(12.5);
        System.out.println("Enter the new bonus of the Employee: ");
        bonus=scanobj.nextDouble();
        System.out.println("*****The details of employee2 object are as follows:*****");
        System.out.println(employee2.toString());
        System.out.println("The weekly salary of the Employee is: $"+employee2.calcWeeklySalary());
        System.out.println("The Annual salary of the Employee is: $"+employee2.calcAnnualSalary());
        System.out.println("The yearly insurance of the Employee is: $"+employee2.calcYearlyInsurance());
        System.out.println("The yearly pf of the Employee is: $"+employee2.calcYearlyPfAmount());
        System.out.println("The annual gross salary of the Employee is: $"+employee2.calcAnnualGrossSalary(bonus));
        System.out.println("The gross annual net pay of the Employee is: $"+employee2.calcAnnualNetPay(bonus));
    }
    
}
