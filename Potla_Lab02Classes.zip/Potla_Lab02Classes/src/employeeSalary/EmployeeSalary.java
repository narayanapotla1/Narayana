/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package employeeSalary;

/**
 *
 * @author S555504 Narayana Potla
 */
public class EmployeeSalary {
    
     private double HOURLY_WAGE=20.0;
    private double insurancePercentage;
    private double taxPercentage; 
    private double pfPercentage;
    private int HOURS=20;
/**
 * It is a constructor with no arguments
 */
    public EmployeeSalary() {
    }
/**
 * Constructor with parameters which is used to set values
 * @param insurancePercentage value from user
 * @param taxPercentage value from user
 * @param pfPercentage value from user
 */
    public EmployeeSalary(double insurancePercentage, double taxPercentage, double pfPercentage) {
        this.insurancePercentage = insurancePercentage;
        this.taxPercentage = taxPercentage;
        this.pfPercentage = pfPercentage;
    }
/**
 * 
 * @param HOURLY_WAGE
 * This method is used to set Hour_WAGE value
 */
    public void setHOURLY_WAGE(double HOURLY_WAGE) {
        this.HOURLY_WAGE = HOURLY_WAGE;
    }
    
    
/**
 * 
 * @param insurancePercentage 
 *This method is used to set insurancePercentage value
 */
    public void setInsurancePercentage(double insurancePercentage) {
        this.insurancePercentage = insurancePercentage;
    }
/**
 * 
 * @param taxPercentage
 * This method is used to set taxPercentage value
 */
    public void setTaxPercentage(double taxPercentage) {
        this.taxPercentage = taxPercentage;
    }
/**
 * 
 * @param pfPercentage
 * This method is used to set pfPercentage value
 */
    public void setPfPercentage(double pfPercentage) {
        this.pfPercentage = pfPercentage;
    }
/**
 * This method is used to get HOURLY_WAGE value
 * @return HOURLY_WAGE
 */
    public double getHOURLY_WAGE() {
        return HOURLY_WAGE;
    }
/**
 * This method is used to get getInsurancePercentage value
 * @return insurancePercentage
 */
    public double getInsurancePercentage() {
        return insurancePercentage;
    }
/**
 * This method is used to get getTaxPercentage value
 * @return taxPercentage
 */
    public double getTaxPercentage() {
        return taxPercentage;
    }
/**
 * This method is used to get getPfPercentage value
 * @return pfPercentage
 */
    public double getPfPercentage() {
        return pfPercentage;
    }
/**
 * This method is used to calculate Weekly Salary
 * @return weeklySalary
 */
    public double calcWeeklySalary(){
        double weeklySalary;
        weeklySalary=HOURLY_WAGE*HOURS;
        return weeklySalary;
    }
    
    /**
     * This method is used to calculate Annual Salary
     * @return annualSalary
     */
    public double calcAnnualSalary(){
        double annualSalary;
        annualSalary=calcWeeklySalary()*4*12;
        return annualSalary;
    }
/**
 * This method is used to calculate yeralyInsurance
 * @return yearlyInsurance
 */    
    public double calcYearlyInsurance(){
        double yearlyInsurance;
        yearlyInsurance=calcAnnualSalary()*(this.insurancePercentage)/100;
        return yearlyInsurance;
    }
 /**
  * This method is used to calculate yeralyPfAmount
  * @return yeralyPfAmount
  */   
    public double calcYearlyPfAmount(){
        double yearlyPfAmount;
        yearlyPfAmount=calcAnnualSalary()*(this.pfPercentage)/100;
        return yearlyPfAmount;
    }
/**
 * This method is used to calculate AnnualGrossSalary
 * @param bonus value of bonus from user
 * @return AnnualGrossSalary
 */    
    public double calcAnnualGrossSalary(double bonus){
        double AnnualGrossSalary;
        AnnualGrossSalary=calcAnnualSalary()+bonus;
        return AnnualGrossSalary;
    }
 /**
  * This method is used to calculate AnnualNetPay
  * @param bonus value of bonus from user
  * @return AnnualNetPay
  */   
    public double calcAnnualNetPay(double bonus){
        double AnnualNetPay;
        AnnualNetPay=calcAnnualGrossSalary(bonus)-((calcAnnualGrossSalary(bonus)*this.taxPercentage)/100)-(calcYearlyInsurance())-(calcYearlyPfAmount());
        return AnnualNetPay; 
    }
/**
 * This method is used to return the values of the declared attributes
 */
    @Override
    public String toString() {
        return "wage Per Hour: " + HOURLY_WAGE + "\ninsurancePercentage: " + insurancePercentage + "\ntaxPercentage: " + taxPercentage + "\npfPercentage: " + pfPercentage + "\nHOURS: " + HOURS ;
    }
    
}
