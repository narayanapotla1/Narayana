/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author S555504 Narayana Potla
 */
public class Animal {
    
    private String name;
    private int age;
    private double weight;
    private double height;
    private boolean domestic;

    public Animal(String name, int age, double weight, double height, boolean domestic) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
        this.domestic = domestic;
    }

    public Animal() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public boolean isDomestic() {
        return domestic;
    }

    public void setDomestic(boolean domestic) {
        this.domestic = domestic;
    }

    @Override
    public String toString() {
        return "Animal name : " + name + "\n Animal age : " + age + "\n Animal weight : " + weight + "\n Animal height : " + height + "\n Is domestic : " + domestic ;
    }
    
    
    
}
