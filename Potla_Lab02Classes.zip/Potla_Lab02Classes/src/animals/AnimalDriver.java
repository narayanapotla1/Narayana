/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author S555504 Narayana Potla
 */
public class AnimalDriver {
    
    public static void main(String[] args){
    
    Animal obj1Animal=new Animal();
    System.out.println("*Testing toString method on obj1Animal*");
    System.out.println(obj1Animal.toString());
    obj1Animal.setName("Monkey");
    obj1Animal.setAge(12);
    obj1Animal.setWeight(10.5);
    obj1Animal.setHeight(12.5);
    obj1Animal.setDomestic(true);
    System.out.println("*****Testing toString method on obj1Animal******");
    System.out.println(obj1Animal.toString());
    System.out.println("*****Testing Getter methods on obj1Animal******");
        System.out.println("Name of the Animal: " +obj1Animal.getName());
        System.out.println("Age of the Animal: " +obj1Animal.getAge());
        System.out.println("Weight of the Animal: " +obj1Animal.getWeight());
        System.out.println("Height of the Animal: " +obj1Animal.getHeight());
        System.out.println("Is Domestic: "+obj1Animal.isDomestic());
        
        Animal obj2Animal=new Animal("Lion",5,5.5,7.5,false);
        
        System.out.println("*****Testing toString method on obj2Animal******");
        System.out.println(obj2Animal.toString());
        
        System.out.println("*****Testing Getter methods on obj2Animal******");
        System.out.println("Name of the Animal: " +obj2Animal.getName());
        System.out.println("Age of the Animal: " +obj2Animal.getAge());
        System.out.println("Weight of the Animal: " +obj2Animal.getWeight());
        System.out.println("Height of the Animal: " +obj2Animal.getHeight());
        System.out.println("Is Domestic: "+obj2Animal.isDomestic());
        
        
        
        
        
    }
    
    
}
